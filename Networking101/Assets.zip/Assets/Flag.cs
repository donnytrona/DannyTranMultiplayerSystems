﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class Flag : NetworkBehaviour {

	enum State
	{
		Available,
		Possessed
	};

	[SyncVar]
	State m_state;

	// Use this for initialization
	void Start () {
		Vector3 spawnPoint;
		ObjectSpawner.RandomPoint(this.transform.position, 10.0f, out spawnPoint);
		this.transform.position = spawnPoint;
		GetComponent<MeshRenderer> ().enabled = false;
	}

	void OnTriggerEnter()
	{
		//make sure flag is visible, and isLocalAuthority
		//this should be disabled while the flag is in posession
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
