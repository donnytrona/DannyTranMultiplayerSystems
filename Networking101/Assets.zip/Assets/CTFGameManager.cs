﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class CTFGameManager : NetworkBehaviour {
    public int m_numPlayers;
    public float m_gameTime;
    public int ActivePlayers { set; get; }

    public GameObject m_flag = null;

    public enum CTF_GameState
    {
        GS_WaitingForPlayers,
        GS_Ready,
        GS_InGame,
    }

    [SyncVar]
    CTF_GameState m_gameState = CTF_GameState.GS_WaitingForPlayers;

    public void IncrementActivePlayers()
    {
        ActivePlayers++;
        Debug.Log("Active Players Increment: " + ActivePlayers);
    }

    public void DecrementActivePlayers()
    {
        ActivePlayers--;
    }

    public bool SpawnFlag()
    {
        Debug.Log("SpawnFlag");
        GameObject flag = Instantiate(m_flag, new Vector3(0, 0, 0), new Quaternion());
        NetworkServer.Spawn(flag);
        return true;
    }

	// Use this for initialization
	void Start () {
        
        ActivePlayers = 0;
        Debug.Log("Active Players: " + ActivePlayers);
    }
	
	// Update is called once per frame
	void Update ()
    {
	    if(isServer)
        {
            if(m_gameState == CTF_GameState.GS_WaitingForPlayers && CTFNetworkManager.singleton.numPlayers == m_numPlayers)
            {
                m_gameState = CTF_GameState.GS_Ready;
            }
            else if(ActivePlayers < m_numPlayers)
            {
                //change state
                //end game
            }
        }

        CheckGameState();
	}

    public void CheckGameState()
    {
        if (m_gameState == CTF_GameState.GS_Ready)
        {
            //call whatever needs to be called

            if (isServer)
            {
                SpawnFlag();
                //change state to ingame
                m_gameState = CTF_GameState.GS_InGame;
            }
        }
        
    }
}
